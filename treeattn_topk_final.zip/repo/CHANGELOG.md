# Changelog

## v13 (final)
- Three phases. 1: dense + FFN, stopped at a held-out accuracy target (default 0.90) / plateau / budget. 2: tree attention only (splitter + budget predictor) trained against the frozen dense model's extracted attention, teacher-forced layer by layer, no FFN and no labels, stopped at a similarity target (default 0.90) / plateau / budget. 3: tree + FFN, standard training at 1x.
- Needle labels, needle extractor/detector and external label files are gone. The dense head lives in the repo (`treeattn/dense.py`) for training only; the tree model has no dense module; FFN, embeddings and norms are common (`GPT.load_dense`).
- Task sources (`treeattn/sources.py`): language token files and MQAR run through the same phase scripts. `scripts/prepare_tinystories.py` added next to the Wikipedia and PG-19 preparation scripts.
- Similarity metric: share of the dense attention mass outside the always-read keys that the tree read (`far`), also `mass` (all keys).
- Removed (kept in `past/`): spike detector and gate, early-token boost, anti-needle routing loss, needle/MQAR training scripts of v12, `tree_off`, `abs_pos`, diagnostic hooks (`route`, `hit`), external dense scripts.
- Kept deliberately: optional `rope_cap` (v12 runs trained with it = longest training length), the needle-in-Wikipedia evaluation.
- `scripts/check_complexity.py` added.
